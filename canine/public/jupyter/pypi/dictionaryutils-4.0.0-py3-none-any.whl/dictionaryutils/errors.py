class DictionaryError(Exception):
    pass


class URLFetchError(DictionaryError):
    pass
